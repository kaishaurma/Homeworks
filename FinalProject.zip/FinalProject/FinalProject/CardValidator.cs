﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    internal class CardValidator
    {
        private readonly Card card;

        public CardValidator(Card card)
        {
            this.card = card;
        }

        public bool IsInfoValid(string number, string date, string CVC)
        {
            return number == card.CardDetails.CardNumber && date == card.CardDetails.ExpDate && CVC == card.CardDetails.CVC;
        }

        public bool IsPinValid(string pin)
        {
            return pin == card.PinCode;
        }
    }
}
