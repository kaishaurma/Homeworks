﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace FinalProject
{
    internal class CardReader
    {
        public Card Read()
        {
            var sr = new StreamReader("URI");
            var json = sr.ReadToEnd();

            return JsonConvert.DeserializeObject<Card>(json);
        }
    }
}
