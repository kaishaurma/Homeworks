﻿namespace FinalProject
{
    public enum CurrencyEnum
    {
        GEL,
        USD,
        EUR
    }
}