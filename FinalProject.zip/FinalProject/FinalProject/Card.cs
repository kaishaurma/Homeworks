﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    internal class Card
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PinCode { get; set; }
        public decimal AmountGEL { get; set; }
        public decimal AmountUSD { get; set; }
        public decimal AmountEUR { get; set; }

        public CardDetails CardDetails { get; set; }
        public List<Transaction> TransactionHistory { get; set; }
    }

    public class CardDetails
    {
        public string CardNumber { get; set; }
        public string ExpDate { get; set; }
        public string CVC { get; set; }
    }

    public class Transaction
    {
        public DateTime TransactionDate { get; set; }
        public TransactionType TransactionType { get; set; }
        public decimal AmountGEL { get; set; }
        public decimal AmountUSD { get; set; }
        public decimal AmountEUR { get; set; }
    }

    public enum TransactionType
    {
        CheckDeposit,
        GetAmount,
        GetLast5Transaction,
        AddAmount,
        ChangePin,
        ChangeAmount
    }
}
