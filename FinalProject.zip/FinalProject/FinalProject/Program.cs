﻿using Newtonsoft.Json;

namespace FinalProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                var reader = new CardReader();
                var card = reader.Read();

                var validator = new CardValidator(card);

                Console.WriteLine("Enter Card Number:");
                var number = Console.ReadLine();

                Console.WriteLine("Enter Card Date:");
                var date = Console.ReadLine();

                Console.WriteLine("Enter Card CVC:");
                var cvc = Console.ReadLine();

                if (!validator.IsInfoValid(number, date, cvc))
                {
                    Console.WriteLine("Info Incorrect");
                    continue;
                }

                Console.WriteLine("Enter Card PIN:");
                var pin = Console.ReadLine();

                if (!validator.IsPinValid(pin))
                {
                    Console.WriteLine("PIN Incorrect");
                    break;
                }

                Console.Clear();

                MainMenu(card);

                var serialized = JsonConvert.SerializeObject(card);

                var sw = new StreamWriter("URI", false);
                sw.Write(serialized);
            }
        }

        private static void MainMenu(Card card)
        {
            while (true)
            {
                Console.WriteLine("Enter Action");
                Console.WriteLine("0. Exit");
                Console.WriteLine("1. Check Deposit");
                Console.WriteLine("2. Get Amount");
                Console.WriteLine("3. Get Last 5 Transactions");
                Console.WriteLine("4. Add Amount");
                Console.WriteLine("5. Change Pin");
                Console.WriteLine("6. Change Amount");

                var option = Console.ReadLine();

                var isParsed = int.TryParse(option, out int parsedOption);

                if (!isParsed)
                {
                    Console.WriteLine("==================================");
                    continue;
                }

                var cardTransactions = new CardTransactions(card);

                switch (parsedOption)
                {
                    case 0:
                        return;

                    case 1:
                        cardTransactions.CheckDeposit();
                        break;

                    case 2:
                        Console.WriteLine("Amount:");
                        var amountToGet = Console.ReadLine();
                        var getResult = decimal.TryParse(amountToGet, out decimal getAmount);
                        if (getResult)
                        {
                            cardTransactions.GetAmount(getAmount);
                        }
                        break;

                    case 3:
                        cardTransactions.GetLast5Transaction();
                        break;

                    case 4:
                        Console.WriteLine("Amount:");
                        var amountToDeposit = Console.ReadLine();
                        var depositResult = decimal.TryParse(amountToDeposit, out decimal depositAmount);
                        if (depositResult)
                        {
                            cardTransactions.AddAmount(depositAmount);
                        }
                        break;

                    case 5:
                        Console.WriteLine("New Pin:");
                        var newPin = Console.ReadLine();
                        cardTransactions.ChangePin(newPin);
                        break;

                    case 6:
                        Console.WriteLine("Amount:");
                        var amountToConvert = Console.ReadLine();
                        var convertResult = decimal.TryParse(amountToConvert, out decimal convertAmount);
                        if (convertResult)
                        {
                            cardTransactions.AddAmount(convertAmount);
                        }
                        break;

                    default:
                        break;
                }
            }
        }
    }
}
