﻿using System.Net.Http.Headers;

namespace FinalProject
{
    internal class CardTransactions
    {
        private Card card;

        public CardTransactions(Card card)
        {
            this.card = card;
        }

        public void CheckDeposit()
        {
            Console.WriteLine($"AmountGEL: {card.AmountGEL}");
            Console.WriteLine($"AmountUSD: {card.AmountUSD}");
            Console.WriteLine($"AmountEUR: {card.AmountEUR}");
        }

        public void GetAmount(decimal amount)
        {
            if (amount > card.AmountGEL)
            {
                Console.WriteLine("Insufficient funds");
                return;
            }

            card.AmountGEL -= amount;
            AddTransaction(TransactionType.GetAmount);
        }
      
        public void GetLast5Transaction()
        {
            var count = 0;
            foreach (var transaction in card.TransactionHistory)
            {
                if (count == 5)
                {
                    return;
                }

                Console.WriteLine($"Date: {transaction.TransactionDate}");
                Console.WriteLine($"Type: {transaction.TransactionType}");
                Console.WriteLine($"AmountGEL: {transaction.AmountGEL}");
                Console.WriteLine($"AmountUSD: {transaction.AmountUSD}");
                Console.WriteLine($"AmountEUR: {transaction.AmountEUR}");
                Console.WriteLine("==================================");
                count++;
            }

            AddTransaction(TransactionType.GetLast5Transaction);
        }

        public void AddAmount(decimal amount)
        {
            card.AmountGEL += amount;
            AddTransaction(TransactionType.AddAmount);
        }

        public void ChangePin(string pin)
        {
            card.PinCode = pin;
            AddTransaction(TransactionType.ChangePin);
        }

        public void ChangeAmount(decimal amount, CurrencyEnum currency)
        {
            if (amount > card.AmountGEL)
            {
                Console.WriteLine("Insufficient funds");
                return;
            }

            switch (currency)
            {
                case CurrencyEnum.USD:
                    card.AmountGEL -= amount;
                    card.AmountUSD = amount * 2.68m;
                    break;
                case CurrencyEnum.EUR:
                    card.AmountGEL -= amount;
                    card.AmountEUR = amount * 2.94m;
                    break;
            }

            AddTransaction(TransactionType.ChangeAmount);
        }

        private void AddTransaction(TransactionType transactionType)
        {
            Transaction transaction = new Transaction
            {
                TransactionDate = DateTime.Now,
                TransactionType = transactionType,
                AmountGEL = card.AmountGEL,
                AmountEUR = card.AmountEUR,
                AmountUSD = card.AmountUSD
            };

            card.TransactionHistory.Add(transaction);
        }
    }
}